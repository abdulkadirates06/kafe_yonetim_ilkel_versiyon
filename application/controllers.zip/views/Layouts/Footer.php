
    <script src="<?php echo base_url(); ?>/assets/libs/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="<?php echo base_url(); ?>/assets/libs/popper.js/dist/umd/popper.min.js"></script>
    <script src="<?php echo base_url(); ?>/assets/libs/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url(); ?>/assets/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js"></script>
    <script src="<?php echo base_url(); ?>/assets/extra-libs/sparkline/sparkline.js"></script>
    <!--Wave Effects -->
    <script src="<?php echo base_url(); ?>/assets/dist/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="<?php echo base_url(); ?>/assets/dist/js/sidebarmenu.js"></script>
    <!--Custom JavaScript -->
    <script src="<?php echo base_url(); ?>/assets/dist/js/custom.min.js"></script>
    <!--This page JavaScript -->
    <!-- <script src="<?php echo base_url(); ?>/dist/js/pages/dashboards/dashboard1.js"></script> -->
    <!-- Charts js Files -->
    <script src="<?php echo base_url(); ?>/assets/libs/flot/excanvas.js"></script>
    <script src="<?php echo base_url(); ?>/assets/libs/flot/jquery.flot.js"></script>
    <script src="<?php echo base_url(); ?>/assets/libs/flot/jquery.flot.pie.js"></script>
    <script src="<?php echo base_url(); ?>/assets/libs/flot/jquery.flot.time.js"></script>
    <script src="<?php echo base_url(); ?>/assets/libs/flot/jquery.flot.stack.js"></script>
    <script src="<?php echo base_url(); ?>/assets/libs/flot/jquery.flot.crosshair.js"></script>
    <script src="<?php echo base_url(); ?>/assets/libs/flot.tooltip/js/jquery.flot.tooltip.min.js"></script>
    <script src="<?php echo base_url(); ?>/assets//dist/js/pages/chart/chart-page-init.js"></script>

    <script>
    
    
    </script>
       <footer class="footer text-center">
               Copyright <?php echo date("Y");  ?> <a href="http://kadirates.me"><b>K</b></a> <a href="http://dogukandemir.org"><b>D</b></a> Yazılım</a>.
            </footer>